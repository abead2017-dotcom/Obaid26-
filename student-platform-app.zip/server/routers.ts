import { z } from "zod";
import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import * as db from "./db";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Student routes
  student: router({
    getProfile: protectedProcedure.query(async ({ ctx }) => {
      return db.getStudentByUserId(ctx.user.id);
    }),

    getGrades: protectedProcedure.query(async ({ ctx }) => {
      const student = await db.getStudentByUserId(ctx.user.id);
      if (!student) return [];
      return db.getStudentGrades(student.id);
    }),

    getSchedule: protectedProcedure.query(async ({ ctx }) => {
      const student = await db.getStudentByUserId(ctx.user.id);
      if (!student) return [];
      return db.getStudentClasses(student.id);
    }),

    getAssignments: protectedProcedure.query(async ({ ctx }) => {
      const student = await db.getStudentByUserId(ctx.user.id);
      if (!student) return [];
      return db.getStudentAssignments(student.id);
    }),

    updateAssignmentStatus: protectedProcedure
      .input(z.object({
        assignmentId: z.number(),
        completed: z.boolean(),
      }))
      .mutation(async ({ ctx, input }) => {
        const student = await db.getStudentByUserId(ctx.user.id);
        if (!student) throw new Error("Student not found");
        
        await db.updateAssignmentStatus(student.id, input.assignmentId, input.completed);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
