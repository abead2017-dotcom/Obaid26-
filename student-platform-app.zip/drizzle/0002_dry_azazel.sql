ALTER TABLE `classes` MODIFY COLUMN `startTime` varchar(20) NOT NULL;--> statement-breakpoint
ALTER TABLE `classes` MODIFY COLUMN `endTime` varchar(20) NOT NULL;--> statement-breakpoint
ALTER TABLE `students` MODIFY COLUMN `gpa` varchar(10) DEFAULT '0';