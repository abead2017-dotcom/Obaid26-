import { ScrollView, Text, View, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useState } from "react";

interface Class {
  id: string;
  subject: string;
  teacher: string;
  time: string;
  room: string;
  day: string;
}

const mockSchedule: Class[] = [
  { id: "1", subject: "الرياضيات", teacher: "أ. محمد علي", time: "08:00 - 09:00", room: "الفصل 101", day: "السبت" },
  { id: "2", subject: "اللغة العربية", teacher: "أ. فاطمة أحمد", time: "09:15 - 10:15", room: "الفصل 102", day: "السبت" },
  { id: "3", subject: "الفيزياء", teacher: "أ. سارة محمود", time: "10:30 - 11:30", room: "المختبر", day: "السبت" },
  { id: "4", subject: "الكيمياء", teacher: "أ. علي حسن", time: "11:45 - 12:45", room: "المختبر", day: "السبت" },
  { id: "5", subject: "الرياضيات", teacher: "أ. محمد علي", time: "08:00 - 09:00", room: "الفصل 101", day: "الأحد" },
  { id: "6", subject: "التاريخ", teacher: "أ. خالد محمد", time: "09:15 - 10:15", room: "الفصل 103", day: "الأحد" },
  { id: "7", subject: "الجغرافيا", teacher: "أ. نور علي", time: "10:30 - 11:30", room: "الفصل 104", day: "الأحد" },
  { id: "8", subject: "الأحياء", teacher: "أ. ليلى حسن", time: "11:45 - 12:45", room: "المختبر", day: "الأحد" },
];

const days = ["السبت", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء"];

export default function ScheduleScreen() {
  const [selectedDay, setSelectedDay] = useState("السبت");
  const filteredClasses = mockSchedule.filter((cls) => cls.day === selectedDay);

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="px-6 py-4 gap-4">
          {/* رأس الصفحة */}
          <View className="gap-1 mb-2">
            <Text className="text-3xl font-bold text-foreground">جدول الحصص</Text>
            <Text className="text-sm text-muted">جدول دراستك الأسبوعي</Text>
          </View>

          {/* اختيار اليوم */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} className="gap-2">
            <View className="flex-row gap-2">
              {days.map((day) => (
                <Pressable
                  key={day}
                  onPress={() => setSelectedDay(day)}
                  style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
                >
                  <View
                    className={`px-4 py-2 rounded-full border ${
                      selectedDay === day
                        ? "bg-primary border-primary"
                        : "bg-surface border-border"
                    }`}
                  >
                    <Text
                      className={`font-semibold text-sm ${
                        selectedDay === day ? "text-background" : "text-foreground"
                      }`}
                    >
                      {day}
                    </Text>
                  </View>
                </Pressable>
              ))}
            </View>
          </ScrollView>

          {/* قائمة الحصص */}
          {filteredClasses.length > 0 ? (
            <View className="gap-3">
              {filteredClasses.map((cls) => (
                <Pressable
                  key={cls.id}
                  style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
                >
                  <View className="bg-surface rounded-2xl p-5 border border-border gap-3">
                    {/* رأس البطاقة */}
                    <View className="flex-row justify-between items-start">
                      <View className="flex-1 gap-1">
                        <Text className="text-lg font-semibold text-foreground">{cls.subject}</Text>
                        <Text className="text-xs text-muted">المعلم: {cls.teacher}</Text>
                      </View>
                      <View className="bg-primary rounded-lg px-3 py-1">
                        <Text className="text-xs font-semibold text-background">{cls.time}</Text>
                      </View>
                    </View>

                    {/* معلومات الحصة */}
                    <View className="flex-row gap-4 pt-2 border-t border-border">
                      <View className="flex-row items-center gap-2 flex-1">
                        <Text className="text-lg">📍</Text>
                        <View>
                          <Text className="text-xs text-muted">الموقع</Text>
                          <Text className="text-sm font-semibold text-foreground">{cls.room}</Text>
                        </View>
                      </View>
                      <View className="flex-row items-center gap-2 flex-1">
                        <Text className="text-lg">🕐</Text>
                        <View>
                          <Text className="text-xs text-muted">الوقت</Text>
                          <Text className="text-sm font-semibold text-foreground">{cls.time}</Text>
                        </View>
                      </View>
                    </View>
                  </View>
                </Pressable>
              ))}
            </View>
          ) : (
            <View className="items-center justify-center py-8 gap-2">
              <Text className="text-2xl">📭</Text>
              <Text className="text-foreground font-semibold">لا توجد حصص في هذا اليوم</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
