import { ScrollView, Text, View, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";

interface Grade {
  id: string;
  subject: string;
  currentGrade: number;
  average: number;
  highestGrade: number;
  tests: Array<{ name: string; grade: number; date: string }>;
}

const mockGrades: Grade[] = [
  {
    id: "1",
    subject: "الرياضيات",
    currentGrade: 95,
    average: 92,
    highestGrade: 98,
    tests: [
      { name: "اختبار الفصل الأول", grade: 95, date: "2026-02-15" },
      { name: "اختبار الفصل الثاني", grade: 92, date: "2026-02-28" },
    ],
  },
  {
    id: "2",
    subject: "اللغة العربية",
    currentGrade: 88,
    average: 85,
    highestGrade: 92,
    tests: [
      { name: "اختبار الفصل الأول", grade: 88, date: "2026-02-16" },
      { name: "اختبار الفصل الثاني", grade: 85, date: "2026-03-01" },
    ],
  },
  {
    id: "3",
    subject: "الفيزياء",
    currentGrade: 92,
    average: 90,
    highestGrade: 95,
    tests: [
      { name: "اختبار الفصل الأول", grade: 92, date: "2026-02-17" },
      { name: "اختبار الفصل الثاني", grade: 90, date: "2026-03-02" },
    ],
  },
  {
    id: "4",
    subject: "الكيمياء",
    currentGrade: 87,
    average: 86,
    highestGrade: 90,
    tests: [
      { name: "اختبار الفصل الأول", grade: 87, date: "2026-02-18" },
      { name: "اختبار الفصل الثاني", grade: 86, date: "2026-03-03" },
    ],
  },
];

export default function GradesScreen() {
  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="px-6 py-4 gap-4">
          {/* رأس الصفحة */}
          <View className="gap-1 mb-2">
            <Text className="text-3xl font-bold text-foreground">النتائج الدراسية</Text>
            <Text className="text-sm text-muted">متابعة درجاتك في جميع المواد</Text>
          </View>

          {/* قائمة المواد */}
          {mockGrades.map((grade) => (
            <Pressable
              key={grade.id}
              style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
            >
              <View className="bg-surface rounded-2xl p-5 border border-border gap-3">
                {/* رأس البطاقة */}
                <View className="flex-row justify-between items-start">
                  <View className="flex-1 gap-1">
                    <Text className="text-lg font-semibold text-foreground">{grade.subject}</Text>
                    <Text className="text-xs text-muted">الدرجة الحالية</Text>
                  </View>
                  <View className="bg-primary rounded-xl px-4 py-2 items-center">
                    <Text className="text-2xl font-bold text-background">{grade.currentGrade}</Text>
                  </View>
                </View>

                {/* الإحصائيات */}
                <View className="flex-row gap-3">
                  <View className="flex-1 bg-background rounded-lg p-3 items-center">
                    <Text className="text-xs text-muted mb-1">المتوسط</Text>
                    <Text className="text-lg font-bold text-foreground">{grade.average}</Text>
                  </View>
                  <View className="flex-1 bg-background rounded-lg p-3 items-center">
                    <Text className="text-xs text-muted mb-1">أعلى درجة</Text>
                    <Text className="text-lg font-bold text-success">{grade.highestGrade}</Text>
                  </View>
                </View>

                {/* الاختبارات */}
                <View className="gap-2 pt-2 border-t border-border">
                  <Text className="text-xs font-semibold text-muted">الاختبارات الأخيرة</Text>
                  {grade.tests.map((test, idx) => (
                    <View key={idx} className="flex-row justify-between items-center">
                      <Text className="text-sm text-foreground flex-1">{test.name}</Text>
                      <Text className="text-sm font-semibold text-primary">{test.grade}</Text>
                    </View>
                  ))}
                </View>
              </View>
            </Pressable>
          ))}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
