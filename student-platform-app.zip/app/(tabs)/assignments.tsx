import { ScrollView, Text, View, Pressable, TouchableOpacity } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useState } from "react";

interface Assignment {
  id: string;
  subject: string;
  title: string;
  description: string;
  dueDate: string;
  status: "pending" | "completed" | "overdue";
}

const mockAssignments: Assignment[] = [
  {
    id: "1",
    subject: "الرياضيات",
    title: "حل تمارين الفصل الثالث",
    description: "حل جميع التمارين من صفحة 45 إلى 50",
    dueDate: "2026-03-05",
    status: "pending",
  },
  {
    id: "2",
    subject: "اللغة العربية",
    title: "كتابة موضوع تعبير",
    description: "اكتب موضوع تعبير عن أهمية العلم",
    dueDate: "2026-03-04",
    status: "pending",
  },
  {
    id: "3",
    subject: "الفيزياء",
    title: "تقرير عملي",
    description: "إعداد تقرير عن تجربة الحركة",
    dueDate: "2026-03-02",
    status: "overdue",
  },
  {
    id: "4",
    subject: "الكيمياء",
    title: "حل مسائل الفصل الثاني",
    description: "حل المسائل من 1 إلى 20",
    dueDate: "2026-02-28",
    status: "completed",
  },
  {
    id: "5",
    subject: "التاريخ",
    title: "بحث عن الدولة العثمانية",
    description: "بحث شامل عن تاريخ الدولة العثمانية",
    dueDate: "2026-03-06",
    status: "pending",
  },
];

export default function AssignmentsScreen() {
  const [completedIds, setCompletedIds] = useState<string[]>(
    mockAssignments.filter((a) => a.status === "completed").map((a) => a.id)
  );

  const toggleComplete = (id: string) => {
    setCompletedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const getStatusColor = (status: string, isCompleted: boolean) => {
    if (isCompleted) return "success";
    if (status === "overdue") return "error";
    if (status === "pending") return "warning";
    return "primary";
  };

  const getStatusText = (status: string, isCompleted: boolean) => {
    if (isCompleted) return "مكتمل";
    if (status === "overdue") return "متأخر";
    if (status === "pending") return "معلق";
    return "مكتمل";
  };

  const pendingAssignments = mockAssignments.filter(
    (a) => !completedIds.includes(a.id) && a.status !== "completed"
  );
  const completedAssignments = mockAssignments.filter((a) => completedIds.includes(a.id));

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="px-6 py-4 gap-4">
          {/* رأس الصفحة */}
          <View className="gap-1 mb-2">
            <Text className="text-3xl font-bold text-foreground">الواجبات</Text>
            <Text className="text-sm text-muted">تتبع واجباتك الدراسية</Text>
          </View>

          {/* الواجبات المعلقة */}
          {pendingAssignments.length > 0 && (
            <View className="gap-3">
              <Text className="text-lg font-semibold text-foreground">الواجبات المعلقة</Text>
              {pendingAssignments.map((assignment) => (
                <Pressable
                  key={assignment.id}
                  style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
                >
                  <View className="bg-surface rounded-2xl p-5 border border-border gap-3">
                    {/* رأس الواجب */}
                    <View className="flex-row justify-between items-start">
                      <View className="flex-1 gap-1">
                        <Text className="text-lg font-semibold text-foreground">{assignment.title}</Text>
                        <Text className="text-xs text-muted">{assignment.subject}</Text>
                      </View>
                      <View
                        className={`px-3 py-1 rounded-full ${
                          assignment.status === "overdue"
                            ? "bg-error"
                            : "bg-warning"
                        }`}
                      >
                        <Text className="text-xs font-semibold text-background">
                          {getStatusText(assignment.status, false)}
                        </Text>
                      </View>
                    </View>

                    {/* الوصف */}
                    <Text className="text-sm text-muted leading-relaxed">
                      {assignment.description}
                    </Text>

                    {/* تاريخ الاستحقاق والزر */}
                    <View className="flex-row justify-between items-center pt-2 border-t border-border">
                      <View className="flex-row items-center gap-2">
                        <Text className="text-lg">📅</Text>
                        <Text className="text-sm font-semibold text-foreground">
                          {assignment.dueDate}
                        </Text>
                      </View>
                      <TouchableOpacity
                        onPress={() => toggleComplete(assignment.id)}
                        className="bg-primary rounded-lg px-4 py-2"
                      >
                        <Text className="text-background font-semibold text-xs">تم الإنجاز</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </Pressable>
              ))}
            </View>
          )}

          {/* الواجبات المكتملة */}
          {completedAssignments.length > 0 && (
            <View className="gap-3">
              <Text className="text-lg font-semibold text-foreground">الواجبات المكتملة</Text>
              {completedAssignments.map((assignment) => (
                <Pressable
                  key={assignment.id}
                  style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
                >
                  <View className="bg-surface rounded-2xl p-5 border border-border gap-3 opacity-70">
                    {/* رأس الواجب */}
                    <View className="flex-row justify-between items-start">
                      <View className="flex-1 gap-1">
                        <Text className="text-lg font-semibold text-foreground line-through">
                          {assignment.title}
                        </Text>
                        <Text className="text-xs text-muted">{assignment.subject}</Text>
                      </View>
                      <View className="px-3 py-1 rounded-full bg-success">
                        <Text className="text-xs font-semibold text-background">مكتمل</Text>
                      </View>
                    </View>

                    {/* تاريخ الاستحقاق والزر */}
                    <View className="flex-row justify-between items-center pt-2 border-t border-border">
                      <View className="flex-row items-center gap-2">
                        <Text className="text-lg">✅</Text>
                        <Text className="text-sm font-semibold text-foreground">
                          {assignment.dueDate}
                        </Text>
                      </View>
                      <TouchableOpacity
                        onPress={() => toggleComplete(assignment.id)}
                        className="bg-surface border border-border rounded-lg px-4 py-2"
                      >
                        <Text className="text-foreground font-semibold text-xs">إلغاء</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </Pressable>
              ))}
            </View>
          )}

          {/* حالة فارغة */}
          {pendingAssignments.length === 0 && completedAssignments.length === 0 && (
            <View className="items-center justify-center py-12 gap-2">
              <Text className="text-4xl">🎉</Text>
              <Text className="text-foreground font-semibold">لا توجد واجبات</Text>
              <Text className="text-muted text-sm">أنت خالي من الواجبات حالياً</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
