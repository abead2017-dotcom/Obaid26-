import { ScrollView, Text, View, TouchableOpacity, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

interface StudentData {
  name: string;
  className: string;
  lastGrades: Array<{ subject: string; grade: number }>;
  pendingAssignments: number;
  nextClass: { subject: string; time: string; room: string };
}

// بيانات تجريبية - سيتم استبدالها بالبيانات الحقيقية من قاعدة البيانات
const mockStudentData: StudentData = {
  name: "أحمد محمد",
  className: "الصف الأول الثانوي",
  lastGrades: [
    { subject: "الرياضيات", grade: 95 },
    { subject: "اللغة العربية", grade: 88 },
    { subject: "الفيزياء", grade: 92 },
  ],
  pendingAssignments: 3,
  nextClass: { subject: "الرياضيات", time: "10:30 صباحاً", room: "الفصل 101" },
};

export default function HomeScreen() {
  const colors = useColors();

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 px-6 py-4 gap-6">
          {/* رأس الصفحة - الترحيب */}
          <View className="gap-1">
            <Text className="text-3xl font-bold text-foreground">مرحباً، {mockStudentData.name}</Text>
            <Text className="text-sm text-muted">{mockStudentData.className}</Text>
          </View>

          {/* بطاقة ملخص النتائج */}
          <Pressable
            style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
          >
            <View className="bg-surface rounded-2xl p-5 border border-border gap-3">
              <View className="flex-row items-center justify-between">
                <Text className="text-lg font-semibold text-foreground">آخر النتائج</Text>
                <Text className="text-xs bg-primary px-3 py-1 rounded-full text-background font-medium">
                  جديد
                </Text>
              </View>
              <View className="gap-2">
                {mockStudentData.lastGrades.map((item, idx) => (
                  <View key={idx} className="flex-row justify-between items-center pb-2 border-b border-border last:border-b-0 last:pb-0">
                    <Text className="text-sm text-muted flex-1">{item.subject}</Text>
                    <Text className="text-lg font-bold text-primary">{item.grade}</Text>
                  </View>
                ))}
              </View>
              <TouchableOpacity className="bg-primary rounded-lg py-2 mt-2 items-center">
                <Text className="text-background font-semibold text-sm">عرض جميع النتائج</Text>
              </TouchableOpacity>
            </View>
          </Pressable>

          {/* بطاقة الواجبات المعلقة */}
          <Pressable
            style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
          >
            <View className="bg-surface rounded-2xl p-5 border border-border gap-3">
              <View className="flex-row items-center justify-between">
                <Text className="text-lg font-semibold text-foreground">الواجبات المعلقة</Text>
                <View className="bg-warning rounded-full w-8 h-8 items-center justify-center">
                  <Text className="text-background font-bold text-sm">{mockStudentData.pendingAssignments}</Text>
                </View>
              </View>
              <Text className="text-sm text-muted">لديك {mockStudentData.pendingAssignments} واجبات بانتظار الإنجاز</Text>
              <TouchableOpacity className="bg-warning rounded-lg py-2 items-center">
                <Text className="text-background font-semibold text-sm">عرض الواجبات</Text>
              </TouchableOpacity>
            </View>
          </Pressable>

          {/* بطاقة الحصة التالية */}
          <Pressable
            style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
          >
            <View className="bg-gradient-to-br from-primary to-primary rounded-2xl p-5 gap-3">
              <Text className="text-sm font-semibold text-background opacity-80">الحصة التالية</Text>
              <View className="gap-2">
                <Text className="text-2xl font-bold text-background">{mockStudentData.nextClass.subject}</Text>
                <View className="flex-row gap-4">
                  <View className="flex-row items-center gap-2">
                    <Text className="text-background opacity-80">🕐</Text>
                    <Text className="text-sm text-background">{mockStudentData.nextClass.time}</Text>
                  </View>
                  <View className="flex-row items-center gap-2">
                    <Text className="text-background opacity-80">📍</Text>
                    <Text className="text-sm text-background">{mockStudentData.nextClass.room}</Text>
                  </View>
                </View>
              </View>
              <TouchableOpacity className="bg-background rounded-lg py-2 mt-2 items-center">
                <Text className="text-primary font-semibold text-sm">عرض الجدول الكامل</Text>
              </TouchableOpacity>
            </View>
          </Pressable>

          {/* أزرار سريعة */}
          <View className="flex-row gap-3 flex-wrap">
            <TouchableOpacity className="flex-1 min-w-[45%] bg-surface rounded-xl py-3 items-center border border-border">
              <Text className="text-2xl mb-1">📊</Text>
              <Text className="text-xs font-semibold text-foreground text-center">النتائج</Text>
            </TouchableOpacity>

            <TouchableOpacity className="flex-1 min-w-[45%] bg-surface rounded-xl py-3 items-center border border-border">
              <Text className="text-2xl mb-1">📅</Text>
              <Text className="text-xs font-semibold text-foreground text-center">الجدول</Text>
            </TouchableOpacity>

            <TouchableOpacity className="flex-1 min-w-[45%] bg-surface rounded-xl py-3 items-center border border-border">
              <Text className="text-2xl mb-1">✅</Text>
              <Text className="text-xs font-semibold text-foreground text-center">الواجبات</Text>
            </TouchableOpacity>

            <TouchableOpacity className="flex-1 min-w-[45%] bg-surface rounded-xl py-3 items-center border border-border">
              <Text className="text-2xl mb-1">👤</Text>
              <Text className="text-xs font-semibold text-foreground text-center">الملف الشخصي</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
