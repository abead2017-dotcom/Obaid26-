import { ScrollView, Text, View, TouchableOpacity, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useRouter } from "expo-router";

interface StudentProfile {
  name: string;
  studentId: string;
  className: string;
  email: string;
  phone: string;
  gpa: number;
  completedAssignments: number;
  absences: number;
}

const mockProfile: StudentProfile = {
  name: "أحمد محمد علي",
  studentId: "STU-2024-001",
  className: "الصف الأول الثانوي - شعبة أ",
  email: "ahmed.student@school.edu",
  phone: "+966 50 123 4567",
  gpa: 3.85,
  completedAssignments: 24,
  absences: 2,
};

export default function ProfileScreen() {
  const router = useRouter();

  const handleLogout = () => {
    // سيتم استبدال هذا برطق تسجيل الخروج الفعلي
    alert("تم تسجيل الخروج بنجاح");
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="px-6 py-4 gap-6">
          {/* رأس الملف الشخصي */}
          <View className="items-center gap-4 pt-4">
            <View className="w-20 h-20 rounded-full bg-primary items-center justify-center">
              <Text className="text-4xl">👤</Text>
            </View>
            <View className="items-center gap-1">
              <Text className="text-2xl font-bold text-foreground">{mockProfile.name}</Text>
              <Text className="text-sm text-muted">{mockProfile.studentId}</Text>
            </View>
          </View>

          {/* بيانات الطالب */}
          <View className="bg-surface rounded-2xl p-5 border border-border gap-4">
            <Text className="text-lg font-semibold text-foreground">البيانات الشخصية</Text>

            {/* الفصل */}
            <View className="gap-1">
              <Text className="text-xs font-semibold text-muted">الفصل الدراسي</Text>
              <View className="flex-row items-center gap-2">
                <Text className="text-lg">📚</Text>
                <Text className="text-sm text-foreground">{mockProfile.className}</Text>
              </View>
            </View>

            {/* البريد الإلكتروني */}
            <View className="gap-1 pt-2 border-t border-border">
              <Text className="text-xs font-semibold text-muted">البريد الإلكتروني</Text>
              <View className="flex-row items-center gap-2">
                <Text className="text-lg">📧</Text>
                <Text className="text-sm text-foreground">{mockProfile.email}</Text>
              </View>
            </View>

            {/* رقم الهاتف */}
            <View className="gap-1 pt-2 border-t border-border">
              <Text className="text-xs font-semibold text-muted">رقم الهاتف</Text>
              <View className="flex-row items-center gap-2">
                <Text className="text-lg">📱</Text>
                <Text className="text-sm text-foreground">{mockProfile.phone}</Text>
              </View>
            </View>
          </View>

          {/* الإحصائيات */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">الإحصائيات الأكاديمية</Text>

            {/* المعدل التراكمي */}
            <View className="bg-surface rounded-2xl p-5 border border-border gap-3">
              <View className="flex-row justify-between items-center">
                <View className="gap-1">
                  <Text className="text-xs text-muted">المعدل التراكمي</Text>
                  <Text className="text-2xl font-bold text-foreground">{mockProfile.gpa}</Text>
                </View>
                <View className="bg-primary rounded-full w-16 h-16 items-center justify-center">
                  <Text className="text-2xl font-bold text-background">
                    {Math.round((mockProfile.gpa / 4) * 100)}%
                  </Text>
                </View>
              </View>
            </View>

            {/* الواجبات والغيابات */}
            <View className="flex-row gap-3">
              <View className="flex-1 bg-surface rounded-2xl p-4 border border-border gap-2 items-center">
                <Text className="text-3xl">✅</Text>
                <Text className="text-xs text-muted">الواجبات المكتملة</Text>
                <Text className="text-2xl font-bold text-success">{mockProfile.completedAssignments}</Text>
              </View>

              <View className="flex-1 bg-surface rounded-2xl p-4 border border-border gap-2 items-center">
                <Text className="text-3xl">📋</Text>
                <Text className="text-xs text-muted">الغيابات</Text>
                <Text className="text-2xl font-bold text-warning">{mockProfile.absences}</Text>
              </View>
            </View>
          </View>

          {/* الإعدادات والخيارات */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">الإعدادات</Text>

            {/* خيار تغيير كلمة المرور */}
            <Pressable
              style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
            >
              <View className="bg-surface rounded-2xl p-4 border border-border flex-row items-center justify-between">
                <View className="flex-row items-center gap-3">
                  <Text className="text-lg">🔐</Text>
                  <Text className="text-sm font-semibold text-foreground">تغيير كلمة المرور</Text>
                </View>
                <Text className="text-lg text-muted">›</Text>
              </View>
            </Pressable>

            {/* خيار الإشعارات */}
            <Pressable
              style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
            >
              <View className="bg-surface rounded-2xl p-4 border border-border flex-row items-center justify-between">
                <View className="flex-row items-center gap-3">
                  <Text className="text-lg">🔔</Text>
                  <Text className="text-sm font-semibold text-foreground">الإشعارات</Text>
                </View>
                <Text className="text-lg text-muted">›</Text>
              </View>
            </Pressable>

            {/* خيار المساعدة */}
            <Pressable
              style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
            >
              <View className="bg-surface rounded-2xl p-4 border border-border flex-row items-center justify-between">
                <View className="flex-row items-center gap-3">
                  <Text className="text-lg">❓</Text>
                  <Text className="text-sm font-semibold text-foreground">المساعدة والدعم</Text>
                </View>
                <Text className="text-lg text-muted">›</Text>
              </View>
            </Pressable>
          </View>

          {/* زر تسجيل الخروج */}
          <TouchableOpacity
            onPress={handleLogout}
            className="bg-error rounded-2xl py-4 items-center mb-4"
          >
            <Text className="text-background font-semibold text-base">تسجيل الخروج</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
